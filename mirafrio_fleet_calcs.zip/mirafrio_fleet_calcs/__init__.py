# -*- coding: utf-8 -*-
# Adaptações de sistema para rotinas da empresa Mirafrio.

from . import models

from odoo import api, fields, SUPERUSER_ID, _