# -*- coding: utf-8 -*-

from odoo import api, fields, models, _
from odoo.exceptions import UserError, AccessError
from odoo.osv import expression

class FleetVehicle(models.Model):
    _name = 'fleet.vehicle'
    _inherit = ['fleet.vehicle']
    odometer_start = fields.Float(string='Odômetro inicial do cadastro', help='Cadastro de odômetro inicial para contagens.')
    odometer_rodado = fields.Float(string='Total de km rodada a partir do cadastro', help='Contagem de km rodada', readonly=True, compute='_get_difodometer')
    total_liters = fields.Float(string='Total de litros de combustíveis registrados', help='Total de combustíveis registrados com cupons.', readonliy=True, compute='_compute_total_liters')
    kmrendimento = fields.Float(string='Média total rendimento km/l', help='Rendimento aferido conforme registros em km/litro.', readonly=True, compute='_compute_km_liters')
    last_kmrendimento = fields.Float(string='Rendimento último abastecimento', help='Rendimento aferido no último abastecimento', readonly=True, compute='_compute_last_rendimento')

    def _compute_total_liters(self):
        liters_list = self.log_services
        self.total_liters = sum(log_services.liters for log_services in liters_list)

    def _get_difodometer(self):
        for rec in self:
            rec.update({
                'odometer_rodado': rec.odometer-rec.odometer_start,
                })

    def _compute_km_liters(self):
        for rec in self:
            rec.update({
                'kmrendimento': rec.odometer_rodado/rec.total_liters
                })

    def _compute_last_rendimento(self):
        for rec in self:
            rec.update({
                'last_kmrendimento': self.env['fleet.vehicle.log.services'].search([('vehicle_id', '=', rec.id), ('tipocupom', '=', 'Combustível')], order='id desc', limit=1).kmrendimento
                })

class FleetVehicleLogServices(models.AbstractModel):
    _name = 'fleet.vehicle.log.services'
    _inherit = ['fleet.vehicle.log.services']
    liters = fields.Float(string='Litragem abastecida', help='Inserir a litragem total abastecida do cupom')
    tipocupom = fields.Selection([('serviço', 'Serviço'), ('combustivel', 'Combustível'),],'Tipo de custo', default='serviço')
    last_odometer_value = fields.Float(string='Último valor de odômetro registrado', readonly=True)
    kmrendimento = fields.Float(string='Rendimento km/litro', readonly=True)
    iddespesa = fields.Float(string='ID da despesa')
    service_type_id = fields.Many2one(
        'fleet.service.type', 'Service Type', required=False,
        default=lambda self: self.env.ref('fleet.type_service_service_8', raise_if_not_found=False),
    )
    #last_odometer_id = fields.Many2one('fleet.vehicle.log.services', 'ID do último abastecimento', readonly=True)

    @api.model_create_multi
    def create(self, vals_list):
        for data in vals_list:
            if 'odometer' in data and not data['odometer']:
                # if received value for odometer is 0, then remove it from the
                # data as it would result to the creation of a
                # odometer log with 0, which is to be avoided
                del data['odometer']
            if data['liters'] > 0:
                last_odometer_id = self.env['fleet.vehicle.log.services'].search([('vehicle_id', '=', data['vehicle_id']), ('liters', '>', '0')], order='id desc', limit=1)
                data['last_odometer_value'] = last_odometer_id.odometer
                data['kmrendimento'] = (data['odometer']-last_odometer_id.odometer)/data['liters']
            #if data['kmrendimento'] < 0:
            #    raise ValidationError(_('O rendimento em km está abaixo de 0, algo de errado não está certo'))
        return super(FleetVehicleLogServices, self).create(vals_list)

class HrExpense(models.Model):
    _name = 'hr.expense'
    _inherit = ['hr.expense']

    liters = fields.Float(string='Litragem abastecida', help='Inserir a litragem total abastecida do cupom')
    odometer = fields.Float(string='Odômetro registrado no abastecimento')
    car = fields.Many2one('fleet.vehicle', 'Veículo')
    motorista = fields.Many2one('res.partner', 'Motorista') 
    tipodespesa = fields.Char(string='Identificador de tipo de despesa', related='product_id.name')

    @api.model_create_multi
    @api.depends('fleet.service.type')
    def create(self, vals):
        record = super(HrExpense, self).create(vals) 
        if record.product_id.name == 'Abastecimento':
            #if tiposervico == None:
                #tiposervico = self.env.cr.execute("select from fleet_service_type where name = 'Combustível'").fetchall()
                #tiposervico = lambda self, cr, uid, context: self.env['fleet.service.type'].search([('id', '=', 2)])
            #return tiposervico
            self.env['fleet.vehicle.log.services'].create({
                'state': 'done',
                'description': record.name,
                'date': record.date,
                'amount': record.total_amount,
                'liters': record.liters,
                'odometer': record.odometer,
                'purchaser_id': record.motorista.id,
                'vehicle_id': record.car.id,
                'tipocupom': 'combustivel',
                'iddespesa': record.id
                #'service_type_id': fields.selection(_get_tiposervico, 'Tipo serviço', required=True)
                })
        return record

    def write(self, vals):

        res = super(HrExpense, self).write(vals) 

        for rec in self:

            record_ids = self.env['fleet.vehicle.log.services'].search([('iddespesa', '=', rec.id)])

            for record in record_ids:
                if vals.get("name"):
                    record.write({
                        'description': vals.get("name"),     
                })
                if vals.get("date"):
                    record.write({
                        'date': vals.get("date")
                })
                
                record.write({
                        'amount': rec.total_amount
                })

                if vals.get("liters"):
                    record.write({
                        'liters': vals.get("liters")
                })
                if vals.get("odometer"):
                    record.write({
                        'odometer': vals.get("odometer")
                })
                if vals.get("motorista.id"):
                    record.write({
                        'purchaser_id': vals.get("motorista.id")
                }) 

                if vals.get("car.id"):
                    record.write({
                        'vehicle_id': vals.get("car.id")
                })

        #if self.product_id.name == 'Abastecimento' and not vals.get("car"):
         #   raise UserError("Você precisa preencher o campo de veiculo")  

        return res

    def unlink(self):

        override_unlink = super(HrExpense, self).unlink()

        record_ids = self.env['fleet.vehicle.log.services'].search([('iddespesa', '=', self.id)])

        record_ids.unlink()

        return override_unlink

        #record_ids = self.env['fleet.vehicle.log.services'].search([('iddespesa', '=', self.id)])
        #for record in record_ids:
         #   record.write({
          #      
           # })
