# -*- coding: utf-8 -*-

{
    'name' : 'Mirafrio - Fleet Calcs',
    'author' : 'Walter E. Miranda',
    'version': '1.0',
    'category': 'Human Resources/Fleet',
    'depends' : ['base', 'mail', 'uom'],

    'description': """
Module for include liters of fuel in fleet manegement and calcs odometer.
===============================================

Possibilita que sejam incluidos os dados de litragem de combustível no abastecimento dos veiculos e calculo automatico de rendimento.
    """,
    'depends': ['fleet','uom', 'hr_expense'],
    "data": ["views/fleet_vehicle.xml"],
    'installable': True,
    'auto_install': False,
}
